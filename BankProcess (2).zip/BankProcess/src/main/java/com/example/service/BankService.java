package main.java.com.example.service;

import main.java.com.example.model.User;
public interface BankService{
    User registerUser(User user);
    //User processPayment(User user, String transfer);
}
